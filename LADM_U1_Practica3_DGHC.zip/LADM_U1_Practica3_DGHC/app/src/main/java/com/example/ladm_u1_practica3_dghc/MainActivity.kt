package com.example.ladm_u1_practica3_dghc

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {
    var arreglo = arrayOf(0,0,0,0,0,0,0,0,0,0)
    var numero = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Permisos
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_DENIED){ //PREGUNTARE
            //ENTRA SI EL PERMISO ESTA DENEGA
            //ENTRA SI EL PERMISO ESTA DENEGADO
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE),0)

        }else
            mensaje("PERMISOS OTORGADOS")
//Asignar
        btnAsignar.setOnClickListener {
            var p = Integer.parseInt(posicion.text.toString())
            var v =Integer.parseInt(valor.text.toString())

            for (i in 0..9){
                arreglo[p] = v
                numero += ","+arreglo[i].toString()
                AlertDialog.Builder(this).setTitle("Numeros: ")
                    .setMessage("posicion"+i+"--"+numero).show()
            }
            numero=""
        }
//**************************Mostrar
        btnMostrar.setOnClickListener {
            for (i in 0..9){
                numero += ","+arreglo[i].toString()
            }
            AlertDialog.Builder(this).setTitle("Numeros: ")
                .setMessage(numero).show()
            numero = ""
        }
//Guardar sd
        btnSD.setOnClickListener {
            guardarArchivoSD()
        }
//Leer
        btnLeerSD.setOnClickListener {
            leerArchivoSD()
        }
    }


    //Mensaje
    fun mensaje(m : String){
        AlertDialog.Builder(this)
            .setTitle("Atención").setMessage(m)
            .setPositiveButton("OK"){d,i->}.show()
    }
    //Comprobar SD
    fun noSD() : Boolean{
        var estado = Environment.getExternalStorageState()
        if (estado != Environment.MEDIA_MOUNTED){
            return true
        }
        return false
    }
    //Guardar en SD
    fun guardarArchivoSD(){
        if(noSD()){
            mensaje("FALTA MEMORIA EXTERNA")
            return
        }

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var nDirectorio = nomArchivo.text.toString()
            var datosArchivo = File(rutaSD.absolutePath, nDirectorio)

            var flujoSalida = OutputStreamWriter(FileOutputStream(datosArchivo))
            var data:String = ""

            for (i in 0..9){
                data += arreglo[i].toString()+"&"
            }

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()

            mensaje("SE GUARDO CORRECTAMENTE ")

        }catch (error : IOException){
            mensaje(error.message.toString())
        }
    }
    //Leer archivo en SD
    fun leerArchivoSD(){
        if (noSD()){
            mensaje("FALTA MEMORIA EXTERNA")
            return
        }

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var nDirectorio = leerArchivo.text.toString()
            var datosArchivo = File(rutaSD.absolutePath,nDirectorio)

            var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosArchivo)))

            var data = flujoEntrada.readLine()
            var vector = data.split("&")

            for (i in 0..9){
                numero += ","+arreglo[i].toString()
            }
            AlertDialog.Builder(this).setTitle("Numeros: ").setMessage(numero).show()
            //vector[0],vector[1],vector[2]
            flujoEntrada.close()

        }catch (error: IOException){
            mensaje(error.message.toString())
        }

    }

}
